# Gaitsensor
歩容解析につかうプログラムやデータのまとめ
